open powershell

go to c:\Welcome 

docker build -t hello .
docker run  -t hello