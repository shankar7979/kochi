export const data = [
    {
        "id": 10001,
        "name": "sumit kumar",
        "salary": 20000,
        "dob": new Date("1-10-2001")
    },
    {
        "id": 10002,
        "name": "amit kumar",
        "salary": 20000,
        "dob": new Date("12-30-2001")
    },
    {
        "id": 10003,
        "name": "suamn kumar",
        "salary": 20000,
        "dob": new Date("12-30-2001")
    },
    {
        "id": 10004,
        "name": "deepak kumar",
        "salary": 28000,
        "dob": new Date("12-30-2001")
    },
    {
        "id": 10005,
        "name": "anil kumar",
        "salary": 30000,
        "dob": new Date("12-30-2002")
    },
    {
        "id": 10001,
        "name": "amit kumar",
        "salary": 40000,
        "dob": new Date("12-30-2007")
    },

]