import { ExponentPipe } from './exponent.pipe';

describe('ExponentPipe', () => {
  it('create an instance', () => {
    const pipe = new ExponentPipe();
    expect(pipe).toBeTruthy();
  });
});
