cd java-docker-app
docker build -t java-app  .

#java-app is image name

docker run java-app
# any name can be given  with that image will be create image 
  
