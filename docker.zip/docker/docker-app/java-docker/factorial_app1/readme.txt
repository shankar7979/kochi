sudo docker build -t fact1  .
sudo docker run -it  fact1
