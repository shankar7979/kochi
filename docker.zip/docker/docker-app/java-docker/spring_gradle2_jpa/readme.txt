<<<<<<< HEAD
gradle bootRun
------------------

in cmd run gradle test 
or in eclipse run as gradle test\eclipse test

get report at build/reports/tests/test/index.html
=======
docker build -t ss .

docker run -p 8080:9090 -it ss
elinks  http://localhost:8080/prd/getAll

outside  os in widnow os using ip address
elinks  http://192.168.0108:8080/prd/getAll


>>>>>>> b4c4cf8cda5bf4888711e7d56cb167286128a787
