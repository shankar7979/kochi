 docker build -t gradleapp1 .

 docker run -it  gradleapp1

