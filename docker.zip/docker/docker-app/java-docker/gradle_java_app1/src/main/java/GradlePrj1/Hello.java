package GradlePrj1;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Hello{
  public static void  main(String args[])  throws IOException
  {
   Scanner sc= new Scanner(System.in);

   String s=null;
  
  System.out.println(" enter name .. ");
  	 s= sc.next();
	   System.out.println(" name is   "+s);
  
 }
}
