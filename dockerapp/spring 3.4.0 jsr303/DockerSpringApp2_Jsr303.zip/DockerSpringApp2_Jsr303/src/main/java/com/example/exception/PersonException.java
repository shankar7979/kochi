package com.example.exception;

public class PersonException  extends RuntimeException{
    public PersonException(String message) {
        super(message);
    }
}
