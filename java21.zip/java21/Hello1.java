int roll;
String name;
void main(){
    System.out.println("hello world");
    roll=10001;
    name="ram kumar";
    System.out.println("roll is "+roll);
}