void main(){

    //Hello1 h=new Hello1();
    //System.out.println(h.roll);
    System.out.println(new Customer(1001,"ram kumar"));
}